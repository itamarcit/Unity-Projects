using UnityEngine;

public class PlayerGrowth : MonoBehaviour
{
    // [SerializeField] private KeyCode pressForGrowth = KeyCode.Space;

    private void Update()
    {
        // if (Input.GetKeyDown(pressForGrowth))
        // {
        //     transform.localScale += Vector3.up; // This will be where we'll change sprites once we have the art of
        //                                         // different player one weights
        // }
    }

    public void IncraseSize()
    {
        transform.localScale += Vector3.up; // This will be where we'll change sprites once we have the art of
        // different player one weights
    }
}
