using UnityEngine;
using UnityEngine.UI;

public class ScoreText : MonoBehaviour
{
    public int score = 0;
    public Text scoreText;

    private void Start()
    {
        // Initialize the score text
        scoreText.text = "Score: " + score.ToString();
    }

    public void IncreaseScore()
    {
        // Increment the score
        score++;

        // Update the score text
        scoreText.text = "Score: " + score.ToString();
    }
}