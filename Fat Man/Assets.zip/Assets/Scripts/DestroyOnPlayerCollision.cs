using UnityEngine;

public class DestroyOnPlayerCollision : MonoBehaviour
{
	private void OnTriggerEnter2D(Collider2D col)
	{
		if (col.CompareTag("Player"))
		{
			Destroy(gameObject);
		}
	}
}