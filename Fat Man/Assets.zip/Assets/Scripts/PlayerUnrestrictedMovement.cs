using UnityEngine;

public class PlayerUnrestrictedMovement : MonoBehaviour
{
	[SerializeField] private float speed = 2;
	private bool _up;
	private bool _down;
	private bool _right;
	private bool _left;
	private Vector2 _target;
	private Rigidbody2D _rigidbody;

	private void Start()
	{
		_rigidbody = GetComponent<Rigidbody2D>();
	}

	private void Update()
	{
		_up = Input.GetKey(KeyCode.UpArrow);
		_left = Input.GetKey(KeyCode.LeftArrow);
		_down = Input.GetKey(KeyCode.DownArrow);
		_right = Input.GetKey(KeyCode.RightArrow);
	}

	private void FixedUpdate()
	{
		_rigidbody.velocity = Vector2.zero;
		HandleMovement();
	}

	private void HandleMovement()
	{
		_target = Vector2.zero;
		if (_up)
		{
			_target += Vector2.up * (speed * Time.deltaTime);
		}
		else if (_down)
		{
			_target += Vector2.down * (speed * Time.deltaTime);
		}
		else if (_left)
		{
			_target += Vector2.left * (speed * Time.deltaTime);
		}
		else if (_right)
		{
			_target += Vector2.right * (speed * Time.deltaTime);
		}
		_rigidbody.MovePosition(_target + _rigidbody.position);
	}
}