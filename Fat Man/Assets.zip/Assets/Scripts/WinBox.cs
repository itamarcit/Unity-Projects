using UnityEngine;

public class WinBox : MonoBehaviour
{
	private void OnTriggerEnter2D(Collider2D col)
	{
		if (col.CompareTag("Player"))
		{
			print("You won");
		}
	}
}