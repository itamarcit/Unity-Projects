using System.Collections;
using UnityEngine;

public class PlayerCollisionDetection : MonoBehaviour
{
	[SerializeField] private float timeToDie = 2f;
	private bool _isHitByFallingBlocks = false;
	private bool _isHitByWall = false;
	private SpriteRenderer _renderer;
	private Rigidbody2D _rigidbody;

	private void Start()
	{
		_renderer = GetComponent<SpriteRenderer>();
		_rigidbody = GetComponent<Rigidbody2D>();
	}

	private void OnCollisionEnter2D(Collision2D col)
	{
		if (col.collider.CompareTag("Bounds") || col.collider.CompareTag("BottomBound"))
		{
			_isHitByWall = true;
		}
		else if (col.collider.CompareTag("Falling Blocks"))
		{
			_isHitByFallingBlocks = true;
		}
	}

	private void OnCollisionExit2D(Collision2D other)
	{
		if (other.collider.CompareTag("Bounds") || other.collider.CompareTag("BottomBound"))
		{
			_isHitByWall = false;
		}
		else if (other.collider.CompareTag("Falling Blocks"))
		{
			_isHitByFallingBlocks = false;
		}
	}

	private void Update()
	{
		if (_isHitByFallingBlocks && _isHitByWall)
		{
			StartCoroutine(PlayerDeath());
		}
		Debug.Log("IsHitByFallingBlocks: " + _isHitByFallingBlocks + ", isHitByWall: " + _isHitByWall);
	}

	private IEnumerator PlayerDeath()
	{
		_rigidbody.constraints = RigidbodyConstraints2D.FreezeAll;
		_renderer.color = Color.red;
		yield return new WaitForSeconds(timeToDie);
		Destroy(gameObject);
	}
}
