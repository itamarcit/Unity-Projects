using System.Collections.Generic;
using UnityEngine;

public class ChooseType : MonoBehaviour
{
    public List<GameObject> forms = new();
    public int currentFormIndex = 0;

    private SpriteRenderer spriteRenderer;
    private Rigidbody2D rigidBody;
    private PolygonCollider2D _polygonCollider;

    private void Start()
    {
        // Get the SpriteRenderer and Rigidbody2D components
        spriteRenderer = GetComponent<SpriteRenderer>();
        rigidBody = GetComponent<Rigidbody2D>();
        _polygonCollider = GetComponent<PolygonCollider2D>();

        // Set the initial form
        SetForm(currentFormIndex);
    }

    private void Update()
    {
        // Check for input to change the form
        if (gameObject.CompareTag("Falling Blocks") && Input.GetKeyDown(KeyCode.Tab))
        {
            // Increment the form index and wrap around if necessary
            currentFormIndex = (currentFormIndex + 1) % forms.Count;
            // Set the new form
            SetForm(currentFormIndex);
            // Update the polygon collider to match the new sprite
            UpdatePolygonCollider();
        }
    }

    private void UpdatePolygonCollider()
    {
        Sprite sprite = spriteRenderer.sprite;
        for (int i = 0; i < _polygonCollider.pathCount; i++) _polygonCollider.SetPath(i, new List<Vector2>());
        _polygonCollider.pathCount = sprite.GetPhysicsShapeCount();
        List<Vector2> path = new List<Vector2>();
        for (int i = 0; i < _polygonCollider.pathCount; i++) {
            path.Clear();
            sprite.GetPhysicsShape(i, path);
            _polygonCollider.SetPath(i, path.ToArray());
        }
    }

    private void SetForm(int formIndex)
    {
        SpriteRenderer otherRenderer = forms[formIndex].GetComponent<SpriteRenderer>();
        spriteRenderer.color = otherRenderer.color;
        spriteRenderer.sprite = otherRenderer.sprite;
        transform.localScale = otherRenderer.transform.localScale;
    }
}
