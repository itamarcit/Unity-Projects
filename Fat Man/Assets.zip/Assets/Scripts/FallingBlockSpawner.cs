using System.Collections.Generic;
using UnityEngine;

public class FallingBlockSpawner : MonoBehaviour
{
	[SerializeField] private GameObject fallingBlockPrefab;
	private List<GameObject> _blocks = new();
	private GameObject _activeFallingBlock;

	private void Start()
	{
		InitializeNewBlock();
	}

	private void Update()
	{
		if (_activeFallingBlock.CompareTag("BottomBound"))
		{
			InitializeNewBlock();
		}
	}

	private void InitializeNewBlock()
	{
		_activeFallingBlock = Instantiate(fallingBlockPrefab, transform.position, Quaternion.identity);
		_blocks.Add(_activeFallingBlock);
	}
}