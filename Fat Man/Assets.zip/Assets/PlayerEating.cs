using UnityEngine;

public class PlayerEating : MonoBehaviour
{
	[SerializeField] private ScoreText score;
	private void OnTriggerEnter2D(Collider2D col)
	{
		if (col.CompareTag("Apple"))
		{
			score.IncreaseScore();
			transform.localScale += Vector3.up;
		}
	}
}
