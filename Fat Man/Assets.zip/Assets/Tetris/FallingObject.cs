using System;
using UnityEngine;

public class FallingObject : MonoBehaviour
{
#region Fields
	[SerializeField] private GameObject fallingBlockPrefab;
	[SerializeField] private Vector3 startVector = new Vector3(0, 3.5f, 0);
	[SerializeField] private float fallSpeed = 10f;
	[SerializeField] private float leftRightSpeed = 10f;
	[SerializeField] private float speedIncreaseModifier = 3.5f;
	[SerializeField] private int rotationDegrees = 90;
	private bool _moveLeft;
	private bool _moveRight;
	private bool _moveDown;
	private bool _isFalling = false;
	private bool _isFallingFast = false;
	private bool _finishedMovement = false;
	private Rigidbody2D _rigidbody;
	private Vector2 _direction;
	private Vector2 _target;
#endregion

	private void Start()
	{
		_rigidbody = GetComponent<Rigidbody2D>();
		_direction = Vector2.zero;
		_target = _rigidbody.position;
	}

	private void OnCollisionEnter2D(Collision2D col)
	{
		if (col.collider.CompareTag("BottomBound"))
		{
			_finishedMovement = true;
			_rigidbody.bodyType = RigidbodyType2D.Static;
			// Once it stops moving, it is no longer a falling block and it becomes part of the bounding box
			gameObject.tag = "BottomBound";
		}
	}

	private void Update()
	{
		if (!_finishedMovement)
		{
			HandleRotation();
			DownMovement();
			LeftRightMovementInput();
		}
	}

	private void FixedUpdate()
	{
		_direction = DownMovement();
		_direction += LeftRightMovement();
		_target = _rigidbody.position + _direction;
		_rigidbody.MovePosition(Vector3.MoveTowards(transform.position, _target, 
			Time.deltaTime * leftRightSpeed));
	}

	private void HandleRotation()
	{
		if (_isFallingFast) return;
		if (Input.GetKeyDown(KeyCode.W))
		{
			transform.Rotate(0, 0, rotationDegrees);
		}
	}

	private void LeftRightMovementInput()
	{
		if (Input.GetKey(KeyCode.A))
		{
			_moveLeft = true;
		}
		if (Input.GetKey(KeyCode.D))
		{
			_moveRight = true;
		}
	}

	private Vector2 LeftRightMovement()
	{
		if (_isFallingFast) return Vector2.zero;
		Vector2 result = Vector2.zero;
		if (_moveLeft)
		{
			result = Vector3.left * (Time.deltaTime * leftRightSpeed);
			_moveLeft = false;
		}
		if (_moveRight)
		{
			result = Vector3.right * (Time.deltaTime * leftRightSpeed);
			_moveRight = false;
		}
		return result;
	}

	private Vector2 DownMovement()
	{
		if (Input.GetKeyDown(KeyCode.S) && !_isFalling && !_finishedMovement)
		{
			_moveDown = true;
			_isFalling = true;
		}
		else if (Input.GetKeyDown(KeyCode.S) && _isFalling)
		{
			_isFallingFast = true;
		}
		if (_isFalling)
		{
			return Vector2.down * (Time.deltaTime * (_isFallingFast ? fallSpeed * speedIncreaseModifier : fallSpeed));
		}
		return Vector2.zero;
	}
}